-- Aposta_User [rel16]
alter table `aposta`  add column  `user_oid`  integer;
alter table `aposta`   add index fk_aposta_user (`user_oid`), add constraint fk_aposta_user foreign key (`user_oid`) references `user` (`oid`);


