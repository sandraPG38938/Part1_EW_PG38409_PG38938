-- Aposta_Resultado [rel7]
alter table `resultado`  add column  `aposta_oid`  integer;
alter table `resultado`   add index fk_resultado_aposta (`aposta_oid`), add constraint fk_resultado_aposta foreign key (`aposta_oid`) references `aposta` (`oid`);


