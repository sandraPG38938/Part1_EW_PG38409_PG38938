-- Aposta [ent2]
alter table `aposta`  add column  `ganha`  varchar(255);
alter table `aposta`  add column  `empate`  varchar(255);
alter table `aposta`  add column  `perde`  varchar(255);


