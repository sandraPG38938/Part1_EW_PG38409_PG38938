-- Aposta_Resultado [rel8]
create table `aposta_resultado` (
   `aposta_oid`  integer not null,
   `resultado_oid`  integer not null,
  primary key (`aposta_oid`, `resultado_oid`)
);
alter table `aposta_resultado`   add index fk_aposta_resultado_aposta (`aposta_oid`), add constraint fk_aposta_resultado_aposta foreign key (`aposta_oid`) references `aposta` (`oid`);
alter table `aposta_resultado`   add index fk_aposta_resultado_resultado (`resultado_oid`), add constraint fk_aposta_resultado_resultado foreign key (`resultado_oid`) references `resultado` (`oid`);


