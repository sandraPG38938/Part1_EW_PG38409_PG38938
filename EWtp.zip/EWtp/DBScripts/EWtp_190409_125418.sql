-- Resultado_Aposta [rel10]
alter table `resultado`  add column  `aposta_oid_2`  integer;
alter table `resultado`   add index fk_resultado_aposta_2 (`aposta_oid_2`), add constraint fk_resultado_aposta_2 foreign key (`aposta_oid_2`) references `aposta` (`oid`);


-- Aposta_Resultado [rel9]
alter table `aposta`  add column  `resultado_oid`  integer;
alter table `aposta`   add index fk_aposta_resultado (`resultado_oid`), add constraint fk_aposta_resultado foreign key (`resultado_oid`) references `resultado` (`oid`);


