-- Aposta [ent2]
alter table `aposta`  add column  `aposta`  varchar(255);


-- Equipa_Evento [rel12]
alter table `evento`  add column  `equipa_oid`  integer;
alter table `evento`   add index fk_evento_equipa (`equipa_oid`), add constraint fk_evento_equipa foreign key (`equipa_oid`) references `equipa` (`oid`);


-- Resultado_Evento [rel13]
alter table `evento`  add column  `resultado_oid`  integer;
alter table `evento`   add index fk_evento_resultado (`resultado_oid`), add constraint fk_evento_resultado foreign key (`resultado_oid`) references `resultado` (`oid`);


-- Evento_Aposta [rel14]
alter table `aposta`  add column  `evento_oid`  integer;
alter table `aposta`   add index fk_aposta_evento (`evento_oid`), add constraint fk_aposta_evento foreign key (`evento_oid`) references `evento` (`oid`);


