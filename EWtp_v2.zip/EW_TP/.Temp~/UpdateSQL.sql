-- User_Aposta [rel1]
create table `user_aposta` (
   `user_oid`  integer not null,
   `aposta_oid`  integer not null,
  primary key (`user_oid`, `aposta_oid`)
);
alter table `user_aposta`   add index fk_user_aposta_user (`user_oid`), add constraint fk_user_aposta_user foreign key (`user_oid`) references `user` (`oid`);
alter table `user_aposta`   add index fk_user_aposta_aposta (`aposta_oid`), add constraint fk_user_aposta_aposta foreign key (`aposta_oid`) references `aposta` (`oid`);


